//
//  KAPubStatus.h
//  Copyright © 2018 AppicPlay. All rights reserved.
//

#ifndef KAPubStatus_h
#define KAPubStatus_h

typedef NS_ENUM(NSInteger, KAPubStatusCode){
    KAPubInvalidConfig                          = 55001,       //invalid config
    KAPubRedeemSwitchClose                      = 55002,       //兑换码关闭
    KAPubPaySwitchClose                         = 55003,       //支付关闭
    KAPubPayModeInvalidConfig                   = 55004,       //后台没有配置受支持的支付方式
    KAPubPayCancel                              = 55005,       //主动取消支付
    KAPubPayModeInvalid                         = 55006,       //不支持的支付方式
    KAPubPayModeNotSupport                      = 55007,       //当前条件不满足使用该支付方式
    KAPubUnKnowReason                           = 55009,       //不明原因
    KAPubNotIAPConfig                           = 55008,       //不明原因
    KAPubPaymentSuccess                         = 55010,       //支付成功
    KAPubPayPhoneClose                          = 55011,       //手机关闭了应用内付费
    KAPubRedeemInvalid                          = 55012,       //兑换码无效
    KAPubSwitchClose                            = 55013,       //pub closed
    KAPubPayOrderVerifyFailed                   = 55014,       //订单验证失败
};

#endif /* KAPubStatus_h */
