//
//  KAAdNativeExpress.h
//  Copyright © 2018 AppicPlay. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class KAAdNativeExpress;

@protocol KAAdNativeExpressDelegate <NSObject>
/**
 * Native ad request is complete with a Native Ad
 */
- (void) nativeExpressAdRequestCompletedWithAd:(nonnull KAAdNativeExpress *)nativeAd;

/**
 * Native ad request failed with slot and error describing the reason
 */
- (void) nativeExpressAdRequestFailedWithAd:(nonnull KAAdNativeExpress *)nativeAd
                                 withStatus:(nonnull NSError *)nativeAdStatus;

@optional
/**
 * Notifies the delegate that the native ad has clicked.
 */
- (void) nativeExpressAdDidClicked:(nonnull KAAdNativeExpress *)native;


@end

@interface KAAdNativeExpress : NSObject

@property (nonatomic, weak, nullable) id <KAAdNativeExpressDelegate> delegate;
/**
 * The slot ID used to request the native ad.
 */
@property (nonatomic, strong, readonly, nonnull) NSString *ka_slot;
/**
 * The title of the native ad.
 */
@property (nonatomic, strong, readonly, nonnull) NSString *ka_adTitle;
/**
 * The description of the native ad.
 */
@property (nonatomic, strong, readonly, nonnull) NSString *ka_adDescription;
/**
 * The icon UIImageView.
 */
@property (nonatomic, strong, readonly, nullable) UIImage *ka_adIcon;
/**
 * The image UIView.
 */
@property (nonatomic, strong, readonly, nullable) UIView *ka_adScreenShots;
/**
 * The video of the native ad.
 */
@property (nonatomic, strong, readonly, nullable) UIView *ka_VideoAdView;
/**
 *广告位展示落地页通过rootviewController进行跳转，必传参数
 */
@property (nonatomic, weak, readwrite) UIViewController *rootViewController;

/**
 * Initialize a Native ad with the given SlotId
 * @param nativeSlot The slotId for loading the native ad
 * @param delegate The delegate to receive callbacks from KAAdNative
 */
- (nonnull instancetype) initWithSlot:(nonnull NSString *)nativeSlot
                             delegate:(nonnull id<KAAdNativeExpressDelegate>)delegate;

/**
 * Loads a Native ad
 */
- (void) load;

/**
 定义原生广告视图中，注册可点击视图
 @param containerView 注册原生广告的容器视图，必传参数
 @note YES注册成功，NO注册失败，请load成功后再调用此方法，同一nativeAd对象请勿重复注册同一视图
 */
- (BOOL)registerContainer:(__kindof UIView *)containerView;

/**
 * Once ad is close and view is remove from screen, use this method to recycle ad assets
 */
- (void) recyclePrimaryView;

@end

NS_ASSUME_NONNULL_END
