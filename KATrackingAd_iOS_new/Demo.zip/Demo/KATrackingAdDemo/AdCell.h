//
//  KAAffiliateSDKTestViewCell.h
//  AffiliateSDKSample
//
//  Created by KA on 10/18/16.
//  Copyright © 2016 KA. All rights reserved.
//
#import "NativeAdController.h"
#import <KASDK/KASDK.h>

@class ViewController;

@interface AdCell : UITableViewCell<KAAdInterstitialDelegate, KAAdSplashDelegate, KAAdIncentivizedDelegate, KAAdBannerDelegate, KAAdNativeExpressDelegate>

@property (nonatomic, strong) NSString *slot, *name;
@property (nonatomic, strong) IBOutlet UIButton *button;
@property (nonatomic, strong) IBOutlet UILabel *label;
@property (nonatomic, strong) KAAdInterstitial *interstitial;
@property (nonatomic, strong) KAAdSplash *splash;
@property (nonatomic, strong) NativeAdController *controller;
@property (nonatomic, strong) KAAdBanner * banner;
@property (nonatomic, strong) KAAdNativeExpress * nativeExpress;
@property (nonatomic, assign) BOOL loadingNative, loadingInterstitial, loadingSplash, loadingBanner, loadingNativeExpress;
@property (nonatomic, assign) ViewController * viewController;

- (void) setupWithSlot:(NSString *)slot
               andName:(NSString *)name
     andViewController:(UIViewController *)controller;

- (void) requestAd;

@end
