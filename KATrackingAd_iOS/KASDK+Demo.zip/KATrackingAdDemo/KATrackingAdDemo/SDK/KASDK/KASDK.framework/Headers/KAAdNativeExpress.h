//
//  KAAdNativeExpress.h
//  Copyright © 2018 AppicPlay. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class KAAdNativeExpress;

@protocol KAAdNativeExpressDelegate <NSObject>
/**
 * Native ad request is complete with a Native Ad
 */
- (void) nativeExpressAdRequestCompletedWithAd:(nonnull KAAdNativeExpress *)nativeAd;

/**
 * Native ad request failed with slot and error describing the reason
 */
- (void) nativeExpressAdRequestFailedWithAd:(nonnull KAAdNativeExpress *)nativeAd
                                 withStatus:(nonnull NSError *)nativeAdStatus;

@optional
/**
 * Notifies the delegate that the native ad has clicked.
 */
- (void) nativeExpressAdDidClicked:(nonnull KAAdNativeExpress *)native;


@end

@interface KAAdNativeExpress : NSObject

@property (nonatomic, weak, nullable) id <KAAdNativeExpressDelegate> delegate;
/**
 * The slot ID used to request the native ad.
 */
@property (nonatomic, strong, readonly, nonnull) NSString *ka_slot;
/**
 * The title of the native ad.
 */
@property (nonatomic, strong, readonly, nonnull) NSString *ka_adTitle;
/**
 * The description of the native ad.
 */
@property (nonatomic, strong, readonly, nonnull) NSString *ka_adDescription;
/**
 * The icon UIImageView.
 */
@property (nonatomic, strong, readonly, nullable) UIImage *ka_adIcon;

/**
 * Initialize a Native ad with the given SlotId
 * @param nativeSlot The slotId for loading the native ad
 * @param delegate The delegate to receive callbacks from KAAdNative
 */
- (nonnull instancetype) initWithSlot:(nonnull NSString *)nativeSlot
                             delegate:(nonnull id<KAAdNativeExpressDelegate>)delegate;

/**
 * Loads a Native ad
 */
- (void) load;

/**
 * Use this method to get main ad view, for which will handle ad impression
 */
- (UIView *) primaryViewOfSize:(CGSize)size withRootViewController:(nonnull UIViewController * )rootViewController;

/**
 * Once ad is close and view is remove from screen, use this method to recycle ad assets
 */
- (void) recyclePrimaryView;

/**
 * Report when Native ad is displayed
 */
- (void) nativeExpressAdRenderedWithView:(nonnull UIView *)nativeAdView;

@end

NS_ASSUME_NONNULL_END
