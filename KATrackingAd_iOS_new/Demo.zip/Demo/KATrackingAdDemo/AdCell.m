//
//  KAAffiliateSDKTestViewCell.m
//  AffiliateSDKSample
//
//  Created by KA on 10/18/16.
//  Copyright © 2016 KA. All rights reserved.
//
#import "AdCell.h"
#import "ViewController.h"

typedef enum : NSUInteger {
    KADemoRequest,
    KADemoSuccess,
    KADemoShow,
    KADemoFail,
    KADemoLoading,
    KADemoHideBanner,
    KADemoShowBanner
} KADemoShowType;

@interface AdCell()
{
    KADemoShowType demoShowType;
}
@end

@implementation AdCell

- (void) setupWithSlot:(NSString *)slot
               andName:(NSString *)name
     andViewController:(UIViewController *)controller
{
    self.viewController = (ViewController *)controller;
    self.slot = slot;
    self.name = name;
    if([self.name isEqualToString:@"Incentivized"] || [self.name isEqualToString:@"Video"])
    {
        [NSTimer scheduledTimerWithTimeInterval:0.25f
                                         target:self
                                       selector:@selector(refresh)
                                       userInfo:nil
                                        repeats:YES];
        self.label.text = [NSString stringWithFormat:@"%@", name];
        [KAAdIncentivized setDelegate:self];
    }else{
        [self updateLabel:demoShowType];
    }
}

- (void) setLoadingNative:(BOOL)loadingNative{
    _loadingNative = loadingNative;
}

- (IBAction) buttonClick:(id)sender{
    if([self.name isEqualToString:@"Native"]){
        if(!self.loadingNative){
            if(self.native){
                self.controller = [[NativeAdController alloc] init];
                [self.controller presentWithAd:self.native andExpressAd:nil];
                self.native = nil;
                [self updateLabel:KADemoRequest];
            }else{
                [self requestAd];
            }
        }
    }else if([self.name isEqualToString:@"NativeExpress"]){
        if(!self.loadingNativeExpress){
            if(self.nativeExpress){
                self.controller = [[NativeAdController alloc] init];
                [self.controller presentWithAd:nil andExpressAd:self.nativeExpress];
                self.nativeExpress = nil;
                [self updateLabel:KADemoRequest];
            }else{
                [self requestAd];
            }
        }
    }else if([self.name isEqualToString:@"Interstitial"]){
        if(!self.loadingInterstitial){
            if(self.interstitial){
                UIWindow *window = [UIApplication sharedApplication].keyWindow;
                [self.interstitial presentFromRootViewController:window.rootViewController];
            }else{
                [self requestAd];
            }
        }
    }else if([self.name isEqualToString:@"Splash"]){
        if(!self.loadingSplash){
            [self requestAd];
        }
    }else if([self.name isEqualToString:@"Incentivized"]){
        if([KAAdIncentivized isReady:NO]){
            UIWindow *window = [UIApplication sharedApplication].keyWindow;
            [KAAdIncentivized presentFromRootViewController:window.rootViewController andSkipButton:NO];
        }
    }else if([self.name isEqualToString:@"Video"]){
        if([KAAdIncentivized isReady:YES]){
            //            UIWindow *window = [UIApplication sharedApplication].keyWindow;
            UIWindow *window = [UIApplication sharedApplication].keyWindow;
            [KAAdIncentivized presentFromRootViewController:window.rootViewController andSkipButton:YES];
        }
    }else if([self.name isEqualToString:@"Banner"])
    {
        if (self.loadingBanner)
        {
            return;
        }
        if (!self.banner)
        {
            self.loadingBanner = YES;
            CGFloat bottomDistance = 0;
            CGSize screenSize = [UIScreen mainScreen].bounds.size;
            if (screenSize.width == 375 && screenSize.height == 812)
            {
                bottomDistance = 34;
            }
            KAAdBannerSize bannerSize = KAAdBannerSize728x90;
            if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone)
            {
                bannerSize = KAAdBannerSize320x50;
            }
            CGRect parentFrame = self.viewController.view.bounds;
            self.banner = [[KAAdBanner alloc] initWithSlot:self.slot withSize:bannerSize delegate:self currentController:self.viewController];
            [self.banner load];
            [self.banner setPosition:CGPointMake(CGRectGetWidth(parentFrame)/2, CGRectGetHeight(parentFrame) - [self.banner getSize].height/2-bottomDistance)];
            [self.viewController.view addSubview:self.banner];

            [self updateLabel:KADemoLoading];
        }
        else
        {
            if (self.banner.hidden)
            {
                demoShowType = KADemoHideBanner;
                [self.banner displayBanner];
            }
            else
            {
                demoShowType = KADemoShowBanner;
                [self.banner dismissBanner];
            }
            [self updateLabel:demoShowType];
        }
    }
}

- (void) refresh{
    BOOL isIncentivized = [self.name isEqualToString:@"Incentivized"];
    if([KAAdIncentivized isReady:!isIncentivized]){
        dispatch_async(dispatch_get_main_queue(), ^{
            self.label.text = [NSString stringWithFormat:@"%@ - Ready", self.name];
        });
    }else{
        dispatch_async(dispatch_get_main_queue(), ^{
            self.label.text = [NSString stringWithFormat:@"%@ - Loading", self.name];
        });
    }
}

- (void) requestAd{
    self.label.text = [NSString stringWithFormat:@"%@ - Loading", self.name];
    if([self.name isEqualToString:@"Native"]){
        self.loadingNative = YES;
        self.native = [[KAAdNative alloc] initWithSlot:self.slot delegate:self];
        [self.native load];
    }else if([self.name isEqualToString:@"NativeExpress"]){
        self.loadingNativeExpress = YES;
        self.nativeExpress = [[KAAdNativeExpress alloc] initWithSlot:self.slot delegate:self];
        [self.nativeExpress load];
    }else if([self.name isEqualToString:@"Interstitial"]){
        self.loadingInterstitial = YES;
        self.interstitial = [[KAAdInterstitial alloc]  initWithSlot:self.slot delegate:self];
        [self.interstitial load];
    }else if([self.name isEqualToString:@"Splash"]){
        self.loadingSplash = YES;
        self.splash = [[KAAdSplash alloc] initWithSlot:self.slot delegate:self];
        UIWindow *window = [UIApplication sharedApplication].keyWindow;

        CGSize bottomSize = [KAAdSplash getBottomViewSize];
        UIView * bottom = [[UIView alloc] initWithFrame:CGRectMake(0, 0, bottomSize.width, bottomSize.height)];
        bottom.backgroundColor = [UIColor whiteColor];

        UIImage * logo = [UIImage imageNamed:@"logo.png"];
        CGFloat scale = bottomSize.height/logo.size.height*0.5;
        CGFloat scaleW = bottomSize.width/logo.size.width*0.35;
        if (logo.size.width * scale > bottomSize.width*0.35)
        {
            scale = scaleW;
        }

        UIImageView * icon = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, logo.size.width*scale, logo.size.height*scale)];
        icon.image = logo;
        icon.center = CGPointMake(bottomSize.width/2, bottomSize.height/2);
        [bottom addSubview:icon];
        [self.splash loadAndPresentWithViewController:window.rootViewController andBackgroundColor:[UIColor blackColor] andBottomView:bottom andBottomViewAutoFitDisplay:YES];

//        [self.splash loadAndPresentWithViewController:window.rootViewController];
    }
}

- (void)updateLabel:(KADemoShowType)type
{
    demoShowType = type;
    switch (type)
    {
        case KADemoRequest:
            self.label.text = [NSString stringWithFormat:@"%@ - slotID:%@ - Request AD", self.name, self.slot];
            break;
        case KADemoFail:
            self.label.text = [NSString stringWithFormat:@"%@ - slotID:%@ - Fail，Request AD", self.name, self.slot];
            break;
        case KADemoShow:
            self.label.text = [NSString stringWithFormat:@"%@ - slotID:%@ - Success, Show AD", self.name, self.slot];
            break;
        case KADemoSuccess:
            self.label.text = [NSString stringWithFormat:@"%@ - slotID:%@ - Request AD", self.name, self.slot];
            break;
        case KADemoShowBanner:
            self.label.text = [NSString stringWithFormat:@"%@ - slotID:%@ - click show banner", self.name, self.slot];
            break;
        case KADemoHideBanner:
            self.label.text = [NSString stringWithFormat:@"%@ - slotID:%@ - click hide banner", self.name, self.slot];
            break;
        case KADemoLoading:
            self.label.text = [NSString stringWithFormat:@"%@ - slotID:%@ - loading...", self.name, self.slot];
            break;
        default:
            break;
    }
}

#pragma mark ======================= Banner Delegate =======================
- (void)bannerAdCompleteLoadingWithAd:(KAAdBanner *)bannerAd
{
    self.loadingBanner = NO;
    NSLog(@"banner ad load success");
    static BOOL isFirstLoad = YES;
    if (isFirstLoad)
    {
        [self updateLabel:KADemoHideBanner];
        isFirstLoad = NO;
    }
}

- (void)bannerAdFailedLoadingForSlot:(NSString *)adSlot withStatus:(NSError *)nativeAdStatus andBanner:(KAAdBanner *)bannerAd
{
    NSLog(@"banner ad load failed, error = %@", nativeAdStatus);
}

- (void)bannerDidDismissScreen:(KAAdBanner *)bannerAd
{

}

- (void)bannerDidPresentScreen:(KAAdBanner *)bannerAd
{

}

#pragma Incentivized

- (void) incentivizedAdPresentDidFailWithError:(NSError *)error{
    NSLog(@"Incentvized Ad present fail with error = %@", error);
}

- (void) incentivizedAdPresentDidSuccess{
    NSLog(@"Incentivized Ad present sucess");
}

- (void) incentivizedAdPresentDidComplete{
    NSLog(@"Incentivized Ad present Complete");
}

- (void) incentivizedAdPresentDidSkip{
    NSLog(@"Incentivized Ad present Skip");
}

#pragma Interstitial

-(void) interstitialAdLoadDidSuccess:(nonnull KAAdInterstitial*)interstitialAd{
    NSLog(@"Interstitial Ad received");
    self.interstitial = interstitialAd;
    [self updateLabel:KADemoShow];
    self.loadingInterstitial = NO;
}

- (void) interstitialAdLoadDidFailForSlot:(nonnull NSString *) interstitialAdSlot
                                withError:(nonnull NSError *) interstitialAdStatus;{
    NSLog(@"Interstitial Ad failed to receive, error = %@", interstitialAdStatus);
    self.interstitial = nil;
    [self updateLabel:KADemoFail];
    self.loadingInterstitial = NO;
}

-(void) interstitialAdDidPresent:(nonnull KAAdInterstitial *)interstitial{
    NSLog(@"Interstitial Ad did present");
}

- (void) interstitialAdDidClick:(nonnull KAAdInterstitial *)splashAd{
    NSLog(@"Interstitial Ad did click");
}

-(void) interstitialAdDidDismiss:(nonnull KAAdInterstitial*)interstitial{
    NSLog(@"Interstitial Ad did dismiss");
    self.interstitial = nil;
    [self updateLabel:KADemoRequest];
}

#pragma Native

- (void) nativeAdRequestCompletedWithAd:(nonnull KAAdNative *)nativeAd{
    NSLog(@"Native Ad received");
    self.native = nativeAd;
    [self updateLabel:KADemoShow];
    self.loadingNative = NO;
}

- (void) nativeAdRequestFailedForSlot:(nonnull NSString *)nativeAdSlot
                           withStatus:(nonnull NSError *)nativeAdStatus{
    NSLog(@"Native Ad failed to receive, error = %@", nativeAdStatus);
    self.native = nil;
    [self updateLabel:KADemoFail];
    self.loadingNative = NO;
}
#pragma mark ======================= Native Express Delegate =======================
- (void) nativeExpressAdDidClicked:(KAAdNativeExpress *)native
{
    NSLog(@"Native Express Click");
}

- (void) nativeExpressAdRequestCompletedWithAd:(KAAdNativeExpress *)nativeAd
{
    NSLog(@"Native Express Ad received");
    self.nativeExpress = nativeAd;

    [self updateLabel:KADemoShow];
    self.loadingNativeExpress = NO;
}

- (void) nativeExpressAdRequestFailedWithAd:(KAAdNativeExpress *)nativeAd withStatus:(NSError *)nativeAdStatus
{
    NSLog(@"Native Express Ad failed to receive, error = %@", nativeAdStatus);
    self.nativeExpress = nil;
    [self updateLabel:KADemoFail];
    self.loadingNativeExpress = NO;
}

#pragma Splash

- (void) splashAdPresentDidSuccess:(nonnull KAAdSplash *)splashAd{
    self.loadingSplash = NO;
    NSLog(@"Splash present success");
}

/**
 * Splash ad request failed with slot and error describing the reason
 */
- (void) splashAdPresentDidFail:(nonnull NSString *)splashAdSlot
                      withError:(nonnull NSError *)error
{
    self.splash = nil;
    [self updateLabel:KADemoFail];
    self.loadingSplash = NO;
    NSLog(@"Splash present fail, error = %@", error);
}

/**
 * Splash ad has been clicked
 */
- (void) splashAdDidClick:(KAAdSplash *)splashAd
{
    NSLog(@"Splash clicked");
}

/**
 * Splash ad has been dismissed
 */
- (void) splashAdDidDismiss:(KAAdSplash *)splashAd
{
    NSLog(@"Splash dismissed");
    self.splash = nil;
    [self updateLabel:KADemoRequest];
}

@end
