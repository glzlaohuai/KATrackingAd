//
//  KAPub.h
//  Copyright © 2018 AppicPlay. All rights reserved.
//
@protocol KAPubDelegate <NSObject>

@optional
//payment
- (void) paymentSuccessWithIapId:(NSString *)iapId;

- (void) paymentFailedIapId:(NSString *)iapId withErrorInfo:(NSError *)error;

- (void) restorePaymentFailed;

- (void) restorePaymentSuccessWithIdentifier:(NSString *)iapId;

//redeem
- (void) redeemCodeSuccessWithData:(NSDictionary *)data withCode:(NSString *)code; // 将成功兑换回的数据包返回给代理进行处理

- (void) redeemCodeFailedWithError:(NSError *)error withCode:(NSString *)code;// 兑换失败，并返回错误码

@end

@interface KAPub : NSObject

+ (void) payWithIAPId:(NSString *)iapId withOrderId:(NSString *)orderId withDelegate:(id<KAPubDelegate>)delegate;

+ (void) restoreCompletedTransactionsWithDelegate:(id<KAPubDelegate>)delegate;

+ (void) redeemCode:(NSString *)code withDelegate:(id<KAPubDelegate>)delegate;

@end
